namespace Psicologia.Web.Data.Abstractions
{
    public interface IId
    {
        public Guid Id { get; set; }
    }
}
