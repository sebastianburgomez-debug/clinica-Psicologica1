namespace Psicologia.Web.Core.Pagination
{
    public class PaginationRequest
    {
        private int _page = 1;
        private int _recordsPerPage = 15;
        private const int MAX_RECORDS_PER_PAGE = 50;
        private const int DEFAULT_RECORDS_PER_PAGE = 15;

        public string? Filter { get; set; }

        public int Page
        {
            get => _page;
            set => _page = value > 0 ? value : 1;
        }

        public int RecordsPerPage
        {
            get => _recordsPerPage;
            set => _recordsPerPage = value <= 0 ? DEFAULT_RECORDS_PER_PAGE : Math.Min(value, MAX_RECORDS_PER_PAGE);
        }

        public static PaginationRequest Default => new PaginationRequest { Page = 1, RecordsPerPage = DEFAULT_RECORDS_PER_PAGE };
    }
}
